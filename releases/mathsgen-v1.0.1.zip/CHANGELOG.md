# v1.0.1 (25/07/2021 2:33PM AEST)
- Added ability to generate addition and subtraction worksheets
- Added missing equals signs to worksheets
# v1.0.0 (23/07/2021 12:28PM AEST)
- Inital commit
