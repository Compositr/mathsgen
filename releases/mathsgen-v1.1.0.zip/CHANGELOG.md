<!-- @format -->

# v1.1.0 (28/07/2021 1:35PM AEST)

- Added timestamp to worksheet
- Added × and ÷ functionality
- Added console prompts to ask user about worksheet type to generate
- Colourised console! (thank you [chalk](https://www.npmjs.com/package/chalk))

# v1.0.1 (25/07/2021 2:33PM AEST)

- Added ability to generate addition and subtraction worksheets
- Added missing equals signs to worksheets

# v1.0.0 (23/07/2021 12:28PM AEST)

- Inital commit
